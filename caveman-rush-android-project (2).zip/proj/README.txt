BUILD THE APK (about 10 minutes)

Install once: Node.js (nodejs.org) and Android Studio (developer.android.com/studio).

In a terminal inside this folder, run these IN ORDER:
  npm install
  npm run prep
  npx cap add android
  npm run android-setup
  npx cap sync android
  npx cap open android

In Android Studio:
  1. Wait for Gradle to finish syncing.
  2. Build > Build Bundle(s) / APK(s) > Build APK(s)
  3. Click "locate": app-debug.apk is your APK. Install it on your phone.

ADS
- Your AdMob App ID is already set by "npm run android-setup".
- The claim button shows a Google TEST rewarded ad. Safe to tap while testing.
- Your Rewarded ad unit ID is already set. TEST_ADS=true shows safe test ads. For the published version, in www/index.html
  set TEST_ADS=false. Then run: npm run build
- NEVER tap your own real ads.
For Google Play use Build > Generate Signed Bundle (AAB).
