const fs=require('fs');
fs.copyFileSync('node_modules/three/build/three.min.js','www/three.min.js');
let h=fs.readFileSync('www/index.html','utf8');
h=h.replace(/https:\/\/cdnjs\.cloudflare\.com\/ajax\/libs\/three\.js\/r128\/three\.min\.js/,'three.min.js');
fs.writeFileSync('www/index.html',h);console.log('ready');
