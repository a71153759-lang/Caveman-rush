const fs=require('fs');const APP_ID='ca-app-pub-9232501937383801~1509621156';
const mp='android/app/src/main/AndroidManifest.xml',sp='android/app/src/main/res/values/strings.xml';
let m=fs.readFileSync(mp,'utf8');
if(!m.includes('APPLICATION_ID'))m=m.replace('</application>','    <meta-data android:name="com.google.android.gms.ads.APPLICATION_ID" android:value="@string/admob_app_id"/>\n    </application>');
if(!m.includes('screenOrientation'))m=m.replace('<activity','<activity android:screenOrientation="portrait"');
fs.writeFileSync(mp,m);
let s=fs.readFileSync(sp,'utf8');
if(!s.includes('admob_app_id'))s=s.replace('</resources>','    <string name="admob_app_id">'+APP_ID+'</string>\n</resources>');
fs.writeFileSync(sp,s);console.log('Android patched with AdMob app ID + portrait lock');
